const categories = require('./categories');
const items = require('./items');

module.exports = {
  categories,
  items
};